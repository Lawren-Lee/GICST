from __future__ import annotations
from typing import List
from gicst.tc_ir import TCIR
from gicst.adapters.base import ProtocolAdapter, FlowIntent
from gicst.core.registry import AdapterRegistry


class IEC104Adapter(ProtocolAdapter):
    name = "IEC-104"

    def compile_intents(self, tc: TCIR) -> List[FlowIntent]:
        intents: List[FlowIntent] = []
        # IEC-104 uses TCP/2404
        acl = {"allow": [{"proto": "tcp", "port": 2404, "roles": ["master", "outstation"]}]}
        qos = {}
        if tc.sla and tc.sla.realtime in {"rtof", "tsn"}:
            qos["realtime"] = tc.sla.realtime
            if tc.sla.period_ms:
                qos["period_ms"] = tc.sla.period_ms
        mirror = {"match": {"tcp_port": 2404, "asdu_types": ["C_SC_NA_1", "C_DC_NA_1"]}, "to": "ids"}
        p4 = {"parse": "iec104", "counters": ["asdu", "cause"], "mirror_on": ["select", "command"]}
        intents.append(FlowIntent(acl=acl, qos=qos, mirror=mirror, p4_profile=p4))
        return intents

AdapterRegistry.register(IEC104Adapter.name, IEC104Adapter)
