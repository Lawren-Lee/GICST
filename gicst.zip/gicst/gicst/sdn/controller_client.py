from __future__ import annotations
from typing import Any, Dict
import logging

log = logging.getLogger(__name__)


class ControllerClient:
    """Abstract client placeholder.
    In offline env, we just log the compiled plan. Later you can subclass to talk to Ryu/ONOS.
    """

    def __init__(self, endpoint: str | None = None):
        self.endpoint = endpoint or "offline://controller"

    def apply_plan(self, plan: Dict[str, Any]) -> None:
        log.info("[SDN] Applying plan to %s:\n%s", self.endpoint, plan)
